package com.company;

public class InvalideWc {


    public InvalideWc(){
    }

    public Boolean Weiger(boolean Beschrikbaar, boolean Betalen, boolean invalide){
    if(Beschrikbaar && Betalen || invalide){
        return true;
}
return false;
}
}

